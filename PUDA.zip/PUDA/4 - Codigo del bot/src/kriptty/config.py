"""Configuración central (variables de entorno / .env).

Modos de operación (TRADING_MODE):
    dry_run  — datos de mercado reales, órdenes simuladas en memoria (por defecto).
    demo     — Bitget Demo Trading (cabecera paptrading=1): exchange real, fondos ficticios.
    live     — dinero real. Requiere además CONFIRM_LIVE_TRADING=yes.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict

ACCOUNT_IDS = ["MAIN"] + [f"SUB{i}" for i in range(1, 12)]

ACCOUNT_DESCRIPTIONS = {
    "MAIN": "Cuenta principal — gestión de capital",
    "SUB1": "News Sentiment (NLP)",
    "SUB2": "Arbitraje estadístico — vasos comunicantes",
    "SUB3": "Copy trading nativo + guardián de riesgo",
    "SUB4": "Scalping intradía (WebSocket)",
    "SUB5": "Macro-shorting (solo cortos)",
    "SUB6": "Funding rate arbitrage (delta-neutral)",
    "SUB7": "Grid adaptativo (Bollinger + ATR)",
    "SUB8": "DCA inteligente (RSI + EMA200 semanal)",
    "SUB9": "Collar dinámico (exposición neta por régimen macro)",
    "SUB10": "Pairs trading por cointegración (market-neutral)",
    "SUB11": "Seguimiento de tendencia SuperTrend 4H",
}


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    trading_mode: Literal["dry_run", "demo", "live"] = "dry_run"
    confirm_live_trading: str = ""
    bitget_uta: bool = False

    # SUB3 queda fuera por defecto: depende de copy trading nativo y de traderIds manuales.
    # SUB10 y SUB11 (nuevas) también: activarlas tras validarlas con kriptty-backtest.
    # SUB4 (scalping 1m) y SUB7 (grid) quedan desactivadas por defecto desde el test de estrés
    # de 3 años (oct. 2026): perdían en todos los escenarios. Reactivarlas solo tras validarlas
    # con histórico real de Bitget y semanas en demo.
    enabled_strategies: str = "SUB1,SUB2,SUB5,SUB6,SUB8,SUB9"

    state_path: str = "data/state.db"
    log_level: str = "INFO"
    dry_run_equity: float = 10_000.0

    # Límites globales de riesgo por cuenta
    max_sl_distance_pct: float = 0.25
    max_daily_loss_pct: float = 0.05
    # Corte por drawdown: si el equity de una subcuenta (spot + futuros) cae más de
    # este % desde su máximo, no abre posiciones durante DRAWDOWN_COOLDOWN_DAYS.
    # Añadido tras el test de estrés de 3 años (SUB7/SUB11 encadenaban pérdidas).
    max_drawdown_pct: float = 0.25
    drawdown_cooldown_days: int = 14
    # Parada dura: si el equity cae más de este % desde su máximo histórico (que no se reinicia
    # tras las pausas), la subcuenta deja de abrir hasta revisión manual (borrar el estado
    # "drawdown" de esa cuenta). Evita que pausas sucesivas del 25% se encadenen.
    max_total_drawdown_pct: float = 0.40
    # Margen máximo comprometido en futuros por subcuenta, como fracción de su equity
    # (spot + futuros). 0.20 = no usar más del 20% de cada cuenta aunque el apalancamiento sea
    # 7x (exposición máxima = 0.20 × 7 = 1.4× el equity). 1.0 = sin límite adicional.
    max_margin_pct: float = 1.0
    # Rampa de capital: el límite anterior no se usa de golpe. Cada subcuenta empieza en el primer
    # escalón (fracción de MAX_MARGIN_PCT) y sube uno cada RAMP_STEP_DAYS si el equity está por
    # encima del de inicio del escalón; baja uno si cae más de RAMP_STEP_BACK_PCT desde ese inicio.
    # Vacío = sin rampa. Ej.: "0.25,0.5,0.75,1" con 1 M$ y 0.2 → 50k, 100k, 150k y 200k en juego.
    capital_ramp: str = ""
    # Duración máxima de una posición de futuros (horas): al pasarla se cierra en el siguiente
    # ciclo. 0 = sin límite. Exentas por diseño: SUB6 (el funding tarda días en pagar las
    # comisiones), SUB8 (DCA en spot) y SUB9 (exposición por régimen; reabriría y solo pagaría comisiones).
    max_hold_hours: float = 0.0
    max_hold_exempt: str = "SUB6,SUB8,SUB9"
    # Apalancamiento por subcuenta, p. ej. "SUB6=3,SUB9=3,SUB10=3". Escala también el riesgo por
    # operación en la misma proporción (como el test de estrés con --scale-risk).
    leverage: str = ""
    # Modo por subcuenta, p. ej. "SUB1=demo,SUB4=demo,SUB7=demo": las agentes nuevas o dudosas
    # operan en Bitget Demo mientras el resto opera con dinero real. Una subcuenta nunca puede ir
    # en un modo más real que TRADING_MODE (dry_run < demo < live): si TRADING_MODE=demo, "SUB4=live"
    # se queda en demo. Las subcuentas en demo usan sus claves de Demo Trading (BITGET_SUBn_*).
    account_modes: str = ""
    # Límite de capital por subcuenta (sustituye a MAX_MARGIN_PCT en esa subcuenta), p. ej.
    # "SUB2=0.1,SUB11=0.1" para los satélites: como mucho 100.000 $ de una subcuenta de 1 M$.
    max_margin_by_account: str = ""
    # Graduación: una subcuenta en demo está lista para dinero real cuando lleva al menos
    # GRADUATION_DAYS días, gana y su drawdown máximo no pasa de GRADUATION_MAX_DD. El bot solo lo
    # avisa (log y MCP): el paso a dinero real lo decide una persona cambiando ACCOUNT_MODES.
    graduation_days: int = 90
    graduation_max_dd: float = 0.10
    ramp_step_days: int = 30
    ramp_step_back_pct: float = 0.05
    # Cuentas que acumulan en caídas por diseño (DCA) y quedan fuera del corte.
    drawdown_exempt: str = "SUB8"
    default_leverage: int = 3
    # Activos base excluidos de los universos (además de acciones/metales/índices conocidos).
    excluded_bases: str = ""
    # Aviso si el reloj local se desvía del de Bitget más de esto (ms).
    max_clock_offset_ms: float = 1000.0

    # Datos externos
    cryptopanic_api_key: str = ""
    cryptopanic_plan: str = "developer"
    newsdata_api_key: str = ""
    fred_api_key: str = ""
    coingecko_api_key: str = ""
    use_finbert: bool = False

    # SUB3
    sub3_trader_ids: str = ""

    # MCP
    mcp_host: str = "127.0.0.1"
    mcp_port: int = 8765
    mcp_read_only: bool = True
    mcp_allowed_hosts: str = "localhost:8765,127.0.0.1:8765"
    # SDK MCP 2.2 (sept. 2026): las sesiones HTTP con estado se cierran tras 30 min sin
    # actividad y el cliente recibe 404. Las herramientas de Kriptty no guardan estado por
    # sesión, así que por defecto el servidor HTTP es stateless (sin sesiones que caduquen).
    mcp_stateless_http: bool = True
    mcp_session_idle_timeout: float = 1800.0

    @staticmethod
    def _pairs(raw: str) -> dict[str, str]:
        out = {}
        for item in raw.split(","):
            if "=" in item:
                acc, value = item.split("=", 1)
                out[acc.strip().upper()] = value.strip()
        return out

    def mode_for(self, account_id: str) -> str:
        """Modo de la subcuenta: el de ACCOUNT_MODES, sin pasar nunca de TRADING_MODE."""
        order = ["dry_run", "demo", "live"]
        wanted = self._pairs(self.account_modes).get(account_id.upper(), self.trading_mode)
        if wanted not in order:
            raise ValueError(f"ACCOUNT_MODES: modo desconocido {wanted!r} para {account_id}")
        return order[min(order.index(wanted), order.index(self.trading_mode))]

    def margin_limit_for(self, account_id: str) -> float:
        value = self._pairs(self.max_margin_by_account).get(account_id.upper())
        return min(1.0, float(value) if value is not None else self.max_margin_pct)

    @property
    def leverage_map(self) -> dict[str, int]:
        out = {}
        for item in self.leverage.split(","):
            if "=" in item:
                acc, lev = item.split("=", 1)
                out[acc.strip().upper()] = int(lev)
        return out

    @property
    def enabled(self) -> set[str]:
        return {s.strip().upper() for s in self.enabled_strategies.split(",") if s.strip()}

    @property
    def sends_real_orders(self) -> bool:
        return self.trading_mode in ("demo", "live")

    def check_live_guard(self) -> None:
        if self.trading_mode == "live" and self.confirm_live_trading.lower() != "yes":
            raise RuntimeError(
                "TRADING_MODE=live requiere CONFIRM_LIVE_TRADING=yes. "
                "Prueba antes en dry_run y demo."
            )


@dataclass(frozen=True)
class Credentials:
    api_key: str
    secret: str
    passphrase: str

    def __repr__(self) -> str:  # nunca volcar secretos en logs
        return f"Credentials(api_key={self.api_key[:4]}…)"


def load_credentials(account_id: str) -> Credentials | None:
    prefix = f"BITGET_{account_id.upper()}_"
    key = os.getenv(prefix + "API_KEY", "")
    secret = os.getenv(prefix + "SECRET", "")
    passphrase = os.getenv(prefix + "PASSPHRASE", "")
    if key and secret and passphrase:
        return Credentials(key, secret, passphrase)
    return None


@lru_cache
def get_settings() -> Settings:
    from dotenv import load_dotenv  # dependencia de pydantic-settings

    load_dotenv()  # para que load_credentials() vea también las claves del .env
    return Settings()
